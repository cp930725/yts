<?php
use think\route;
//Route::bind('home');
//Route::rule('login','home/login/login');
/* return [
    '__pattern__' => [
        'name' => '\w+',
    ],
    '[hello]'     => [
        ':id'   => ['index/hello', ['method' => 'get'], ['id' => '\d+']],
        ':name' => ['index/hello', ['method' => 'post']],
    ],
    'login'=>['home/login/login'],
];
 */